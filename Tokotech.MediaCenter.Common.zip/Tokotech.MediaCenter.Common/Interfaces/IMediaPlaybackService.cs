﻿using System.Collections.Generic;
using System.ServiceModel;

namespace Tokotech.MediaCenter.Common.Interfaces
{
    [ServiceContract(Namespace = "http://www.tokotech.net/Services/MediaCenterControl")]
    public interface IMediaPlaybackService
    {
        [OperationContract]
        void Ping();

        #region PlayControls

        [OperationContract]
        MediaState Play();

        [OperationContract]
        MediaState PrevTrack();

        [OperationContract]
        MediaState SetVolume(double volume);
        
        [OperationContract]
        MediaState GetMediaState();

        [OperationContract]
        IEnumerable<Track> GetCurrentPlaylist();

        [OperationContract]
        MediaState NextTrack();

        [OperationContract]
        MediaState Pause();

        #endregion

        #region Play

        [OperationContract]
        MediaState PlayAll(bool shuffel);

        [OperationContract]
        MediaState PlayArtist(Artist artist, bool enqueue, bool shuffel);

        [OperationContract]
        MediaState PlayAlbum(Album album, bool enqueue, bool shuffel);

        [OperationContract]
        MediaState PlayGenre(Genre genre, bool enqueue, bool shuffel);

        [OperationContract]
        MediaState PlayTrack(Track track, bool enqueue);

        //[OperationContract]
        //MediaState PlayPlaylist(Track track, bool enqueue, bool shuffel);

        [OperationContract]
        MediaState PlayComposer(Composer composer, bool enqueue, bool shuffel);

        [OperationContract]
        MediaState PlayYear(Year year, bool enqueue, bool shuffel);

        #endregion
    }
}