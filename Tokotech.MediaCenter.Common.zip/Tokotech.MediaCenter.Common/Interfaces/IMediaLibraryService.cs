﻿using System;
using System.Collections.Generic;
using System.ServiceModel;

namespace Tokotech.MediaCenter.Common.Interfaces
{
    [ServiceContract(Namespace="http://www.tokotech.net/Services/MediaCenterControl")]
    public interface IMediaLibraryService
    {
        [OperationContract]
        void Ping();

        [OperationContract]
        Version GetServerVersion();

        [OperationContract]
        string GetServicesName();

        [OperationContract]
        IEnumerable<Artist> GetArtists();

        [OperationContract]
        IEnumerable<char> GetArtistsGroupList();

        [OperationContract]
        IEnumerable<Artist> GetArtistsGroup(string startswith);

        [OperationContract]
        int GetArtistCount();

        [OperationContract]
        IEnumerable<Artist> GetArtistRange(int index, int count);

        [OperationContract]
        IEnumerable<Album> GetAlbumsByArtist(Artist artist);

        [OperationContract]
        Album GetAlbum(Album album);

        [OperationContract]
        IEnumerable<Album> GetAlbums();

        [OperationContract]
        Byte[] GetAlbumArtByAlbum(Album album);

        [OperationContract]
        IEnumerable<Album> GetAlbumsWithoutArt();

        [OperationContract]
        IEnumerable<char> GetAlbumsGroupList();

        [OperationContract]
        IEnumerable<Album> GetAlbumGroup(string startswith);

        [OperationContract]
        int GetAlbumsCount();

        [OperationContract]
        IEnumerable<Album> GetAlbumsRange(int index, int count);

        [OperationContract]
        Byte[] GetAlbumArtByTrack(Track track);
        
        [OperationContract]
        IEnumerable<Genre> GetGenres();
        
        [OperationContract]
        int GetGenresCount();

        [OperationContract]
        IEnumerable<Genre> GetGenresRange(int index, int count);
        
        [OperationContract]
        IEnumerable<Album> GetAlbumsByGenre(Genre genre);

        [OperationContract]
        Track GetTrack(Track track);

        [OperationContract]
        IEnumerable<Track> GetTracks();

        [OperationContract]
        int GetTracksCount();

        [OperationContract]
        IEnumerable<Track> GetTracksRange(int index, int count);

        //[OperationContract]
        //IEnumerable<Playlist> GetPlaylists();

        //[OperationContract]
        //int GetPlaylistsCount();

        //[OperationContract]
        //IEnumerable<Playlist> GetPlaylistsRange(int index, int count);

        //[OperationContract]
        //IEnumerable<Album> GetAlbumsByPlaylist(Composer composer);

        [OperationContract]
        IEnumerable<Composer> GetComposers();

        [OperationContract]
        int GetComposersCount();

        [OperationContract]
        IEnumerable<Composer> GetComposersRange(int index, int count);

        [OperationContract]
        IEnumerable<Album> GetAlbumsByComposer(Composer composer);

        [OperationContract]
        IEnumerable<Year> GetYears();

        [OperationContract]
        int GetYearsCount();

        [OperationContract]
        IEnumerable<Year> GetYearsRange(int index, int count);

        [OperationContract]
        IEnumerable<Album> GetAlbumsByYear(Year year);

        [OperationContract]
        IEnumerable<Track> GetLatestPlayedTracks();

        [OperationContract]
        IEnumerable<Track> GetMostPlayedTracks();
    }
}
