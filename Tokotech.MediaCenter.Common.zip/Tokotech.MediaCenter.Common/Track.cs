﻿using System;
using System.Runtime.Serialization;

namespace Tokotech.MediaCenter.Common
{
    [DataContract]
    public class Track
    {
        [DataMember]
        public string AlbumName { get; set; }

        [DataMember]
        public string ArtistName { get; set; }

        [DataMember]
        public string AlbumId { get; set; }

        [DataMember]
        public string CollectionID { get; set; }

        [DataMember]
        public string ComposerName { get; set; }

        [DataMember]
        public TimeSpan Duration { get; set; }

        [DataMember]
        public string FilePath { get; set; }

        [DataMember]
        public DateTime LastPlayed { get; set; }

        [DataMember]
        public int PlayCount { get; set; }

        [DataMember]
        public string Title { get; set; }

        [DataMember]
        public int TrackNumber { get; set; }
    }
}