﻿using System;
using System.Runtime.Serialization;

namespace Tokotech.MediaCenter.Common
{
    [DataContract]
    public class MediaState
    {
        [DataMember]
        public string AlbumName { get; set; }

        [DataMember]
        public string ArtistName { get; set; }

        [DataMember]
        public DateTime CurrentTime { get; set; }

        [DataMember]
        public Track CurrentTrack { get; set; }

        [DataMember]
        public TimeSpan PlaybackPosition { get; set; }

        [DataMember]
        public PlaybackState PlaybackState { get; set; }

        [DataMember]
        public double Volume { get; set; }
    }
}
