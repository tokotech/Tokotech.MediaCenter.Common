﻿using System.Runtime.Serialization;

namespace Tokotech.MediaCenter.Common
{
    [DataContract]
    public class Year
    {
        [DataMember]
        public string ReleaseYear { get; set; }
    }
}