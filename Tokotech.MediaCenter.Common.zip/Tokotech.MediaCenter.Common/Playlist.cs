﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Tokotech.MediaCenter.Common
{
    [DataContract]
    public class Playlist
    {
        [DataMember]
        public string Name { get; set; }

        [DataMember]
        public string DisplayName { get; set; }

        [DataMember]
        public List<Track> Tracks { get; set; }
    }
}