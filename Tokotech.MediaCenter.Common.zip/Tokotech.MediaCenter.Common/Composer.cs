﻿using System.Runtime.Serialization;

namespace Tokotech.MediaCenter.Common
{
    [DataContract]
    public class Composer
    {
        [DataMember]
        public string ComposerName { get; set; }
    }
}