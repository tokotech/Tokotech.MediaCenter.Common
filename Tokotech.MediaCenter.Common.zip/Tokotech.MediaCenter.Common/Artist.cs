﻿using System.Runtime.Serialization;

namespace Tokotech.MediaCenter.Common
{
    [DataContract]
    public class Artist
    {
        [DataMember]
        public string Name { get; set; }
    }
}