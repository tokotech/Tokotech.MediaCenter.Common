﻿using System.Runtime.Serialization;

namespace Tokotech.MediaCenter.Common
{
    [DataContract]
    public class Genre
    {
        [DataMember]
        public string GenreName { get; set; }
    }
}